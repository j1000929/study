package org.study.dao;

public enum Country {
	Korea, USA, UK, Misc
}
